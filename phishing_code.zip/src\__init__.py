"""Phishing detection package."""
